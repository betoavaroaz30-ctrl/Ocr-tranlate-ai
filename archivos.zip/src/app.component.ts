import { Component, ChangeDetectionStrategy, signal, inject, computed, Pipe, PipeTransform } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { GeminiService, ComicTranslationBlock } from './services/gemini.service';
import { Language } from './models/language.model';

@Pipe({ name: 'safeUrl', standalone: true })
export class SafeUrlPipe implements PipeTransform {
  private readonly sanitizer = inject(DomSanitizer);
  transform(url: string): SafeResourceUrl {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [CommonModule, SafeUrlPipe],
  host: {
    '(window:mousemove)': 'dragMove($event)',
    '(window:mouseup)': 'dragEnd()',
  }
})
export class AppComponent {
  private readonly geminiService = inject(GeminiService);

  // General state
  inputText = signal<string>('');
  translatedText = signal<string>('');
  translationExplanation = signal<string | null>(null);
  sourceLanguage = signal<Language>({ code: 'auto', name: 'Auto-detect' });
  targetLanguage = signal<Language>({ code: 'es', name: 'Spanish' });
  isLoading = signal<boolean>(false);
  isTranscribing = signal<boolean>(false);
  error = signal<string | null>(null);
  smartMode = signal<boolean>(false);
  detectedLanguage = signal<string | null>(null);

  // Media translation state
  imageFile = signal<File | null>(null);
  uploadedImagePreview = signal<string | null>(null);
  videoFile = signal<File | null>(null);
  uploadedVideoPreview = signal<string | null>(null);

  // Web page translation state
  translationMode = signal<'text' | 'web' | 'comic' | 'clipboard'>('text');
  webUrlInput = signal<string>('');
  frameUrl = signal<string | null>(null);
  isFrameLoading = signal<boolean>(false);
  
  // Comic translation state
  comicFile = signal<File | null>(null);
  comicPreviewUrl = signal<string | null>(null);
  translatedComicData = signal<ComicTranslationBlock[] | null>(null);
  isTranslatingComic = signal<boolean>(false);

  // --- Overlay Panel State ---
  isPanelVisible = signal<boolean>(true);
  isPanelMinimized = signal<boolean>(false);
  panelPosition = signal<{x: number; y: number}>({ x: 50, y: 50 });

  private isDragging = signal<boolean>(false);
  private dragOffset = signal<{x: number; y: number}>({ x: 0, y: 0 });

  readonly MAX_CHARS = 5000;

  languages = signal<Language[]>([
    { code: 'auto', name: 'Auto-detect' },
    { code: 'en', name: 'English' },
    { code: 'es', name: 'Spanish' },
    { code: 'fr', name: 'French' },
    { code: 'de', name: 'German' },
    { code: 'it', name: 'Italian' },
    { code: 'pt', name: 'Portuguese' },
    { code: 'ja', name: 'Japanese' },
    { code: 'ko', name: 'Korean' },
    { code: 'zh', name: 'Chinese' },
    { code: 'ru', name: 'Russian' },
    { code: 'ar', name: 'Arabic' },
    { code: 'hi', name: 'Hindi' },
  ]);

  languagesForTarget = computed(() => this.languages().filter(l => l.code !== 'auto'));

  // --- Text & Media Translation Methods ---

  async handleTranslate(): Promise<void> {
    if ((!this.inputText() && !this.imageFile()) || this.isLoading() || this.isTranscribing()) {
      return;
    }

    this.isLoading.set(true);
    this.error.set(null);
    this.translatedText.set('');
    this.translationExplanation.set(null);
    this.detectedLanguage.set(null);

    try {
      let textToTranslate = this.inputText();

      if (this.imageFile()) {
        const extractedText = await this.geminiService.extractTextFromImage(this.imageFile()!);
        if (!extractedText) {
          throw new Error("No text could be found in the image.");
        }
        this.inputText.set(extractedText);
        textToTranslate = extractedText;
      }
      
      if (this.videoFile()) {
        textToTranslate = this.inputText();
      }

      if (!textToTranslate.trim()) {
        this.isLoading.set(false);
        return;
      }

      let sourceLangName = this.sourceLanguage().name;

      if (this.sourceLanguage().code === 'auto') {
        const detectedName = await this.geminiService.detectLanguage(textToTranslate);
        if (!detectedName) {
            throw new Error("Could not detect the source language.");
        }
        this.detectedLanguage.set(`Detected: ${detectedName}`);
        sourceLangName = detectedName;
      }

      if (sourceLangName.toLowerCase() === this.targetLanguage().name.toLowerCase()) {
          this.translatedText.set(textToTranslate);
          // If in clipboard mode, switch back to text mode to show the result
          if (this.translationMode() === 'clipboard') {
            this.translationMode.set('text');
          }
          return;
      }

      const result = await this.geminiService.translate(
        textToTranslate,
        sourceLangName,
        this.targetLanguage().name,
        this.smartMode()
      );
      this.translatedText.set(result.translation);
      this.translationExplanation.set(result.explanation);
       // If in clipboard mode, switch back to text mode to show the result
      if (this.translationMode() === 'clipboard') {
        this.translationMode.set('text');
      }
    } catch (e: unknown) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      this.error.set(errorMessage);
    } finally {
      this.isLoading.set(false);
    }
  }

  onInputTextChange(event: Event): void {
    const value = (event.target as HTMLTextAreaElement).value;
    if (value.length <= this.MAX_CHARS) {
        this.inputText.set(value);
    } else {
        (event.target as HTMLTextAreaElement).value = value.slice(0, this.MAX_CHARS);
        this.inputText.set(value.slice(0, this.MAX_CHARS));
    }
  }
  
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;

    const file = input.files[0];
    this.clearAll();

    if (file.type.startsWith('image/')) {
      const allowedTypes = ['image/png', 'image/jpeg', 'image/webp'];
      if (!allowedTypes.includes(file.type)) {
        this.error.set(`Unsupported image type. Please use PNG, JPEG, or WEBP.`);
        return;
      }
      this.imageFile.set(file);
      const reader = new FileReader();
      reader.onload = (e) => this.uploadedImagePreview.set(e.target?.result as string);
      reader.readAsDataURL(file);

    } else if (file.type.startsWith('video/')) {
      const allowedTypes = ['video/mp4', 'video/webm', 'video/ogg'];
       if (!allowedTypes.includes(file.type)) {
        this.error.set(`Unsupported video type. Please use MP4, WebM, or OGG.`);
        return;
      }
      this.videoFile.set(file);
      const reader = new FileReader();
      reader.onload = (e) => this.uploadedVideoPreview.set(e.target?.result as string);
      reader.readAsDataURL(file);
      this.handleVideoTranscription(file);

    } else {
       this.error.set(`Unsupported file type. Please upload an image or video.`);
    }
  }

  private async handleVideoTranscription(file: File): Promise<void> {
    this.isTranscribing.set(true);
    this.error.set(null);
    try {
      const transcript = await this.geminiService.extractTextFromVideo(file);
       if (!transcript) {
        this.error.set("Could not extract any text from the video.");
      }
      this.inputText.set(transcript);
    } catch(e: unknown) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred during transcription.';
      this.error.set(errorMessage);
    } finally {
      this.isTranscribing.set(false);
    }
  }

  swapLanguages(): void {
    const currentSource = this.sourceLanguage();
    const currentTarget = this.targetLanguage();
    
    if (currentSource.code !== 'auto') {
        this.sourceLanguage.set(currentTarget);
        this.targetLanguage.set(currentSource);
    }

    const currentInput = this.inputText();
    this.inputText.set(this.translatedText());
    this.translatedText.set(currentInput);
    this.translationExplanation.set(null);
    this.clearMedia();
  }
  
  private clearMedia(inputElement?: HTMLInputElement): void {
    this.imageFile.set(null);
    this.uploadedImagePreview.set(null);
    this.videoFile.set(null);
    this.uploadedVideoPreview.set(null);
    const fileInput = inputElement || document.querySelector('input[type="file"]') as HTMLInputElement;
    if(fileInput) fileInput.value = '';
  }

  clearAll(): void {
    this.inputText.set('');
    this.translatedText.set('');
    this.translationExplanation.set(null);
    this.error.set(null);
    this.detectedLanguage.set(null);
    this.clearMedia();
    
    this.comicFile.set(null);
    this.comicPreviewUrl.set(null);
    this.translatedComicData.set(null);
  }

  // --- Web Page Translation Methods ---

  handleWebUrlInput(event: Event): void {
    this.webUrlInput.set((event.target as HTMLInputElement).value);
  }

  handleTranslateWebPage(): void {
    this.error.set(null);
    this.frameUrl.set(null);
    let url = this.webUrlInput().trim();
    if (!url) {
      this.error.set('Please enter a website URL.');
      return;
    }

    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = `https://${url}`;
    }

    try {
      new URL(url);
    } catch (_) {
      this.error.set('Please enter a valid URL.');
      return;
    }

    const targetLangCode = this.targetLanguage().code;
    const googleTranslateUrl = `https://translate.google.com/translate?sl=auto&tl=${targetLangCode}&u=${encodeURIComponent(url)}&hl=en`;
    
    this.frameUrl.set(googleTranslateUrl);
    this.isFrameLoading.set(true);
  }
  
  onFrameLoad(): void {
    this.isFrameLoading.set(false);
  }
  
  // --- Comic Translation Methods ---
  
  handleComicFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;
    
    const file = input.files[0];
    const allowedTypes = ['image/png', 'image/jpeg', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      this.error.set(`Unsupported image type. Please use PNG, JPEG, or WEBP.`);
      return;
    }
    
    this.clearAll();
    this.comicFile.set(file);
    const reader = new FileReader();
    reader.onload = (e) => this.comicPreviewUrl.set(e.target?.result as string);
    reader.readAsDataURL(file);
  }

  async handleTranslateComic(): Promise<void> {
    if (!this.comicFile()) return;

    this.isTranslatingComic.set(true);
    this.error.set(null);
    this.translatedComicData.set(null);
    
    try {
      const result = await this.geminiService.translateComicPage(this.comicFile()!, this.targetLanguage().name);
      this.translatedComicData.set(result);
    } catch (e: unknown) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      this.error.set(errorMessage);
    } finally {
      this.isTranslatingComic.set(false);
    }
  }

  // --- Clipboard Method ---
  async handlePasteAndTranslate(): Promise<void> {
    this.error.set(null);
    this.clearAll();
    try {
      if (!navigator.clipboard || !navigator.clipboard.readText) {
        throw new Error("Clipboard API not available. Please use a modern browser.");
      }
      const text = await navigator.clipboard.readText();
      if (!text || !text.trim()) {
        this.error.set("Your clipboard is empty.");
        return;
      }
      this.inputText.set(text);
      await this.handleTranslate();
    } catch (err) {
      const error = err as Error;
      if (error.name === 'NotAllowedError') {
        this.error.set("Permission to read clipboard was denied. Please grant permission in your browser settings.");
      } else {
        this.error.set(`Could not read from clipboard: ${error.message}`);
      }
    }
  }

  // --- General Methods ---

  setTranslationMode(mode: 'text' | 'web' | 'comic' | 'clipboard'): void {
    this.translationMode.set(mode);
    this.error.set(null);
    this.clearAll();
    if (mode === 'web') {
      this.frameUrl.set(null);
    }
  }

  copyToClipboard(): void {
    const textToCopy = this.translatedText() || this.inputText();
    if (textToCopy) {
      navigator.clipboard.writeText(textToCopy).catch(err => {
        console.error('Failed to copy text: ', err);
      });
    }
  }

  setSourceLanguage(langCode: string): void {
    const lang = this.languages().find(l => l.code === langCode);
    if (lang) {
      this.sourceLanguage.set(lang);
    }
  }

  setTargetLanguage(langCode: string): void {
    const lang = this.languages().find(l => l.code === langCode);
    if (lang) {
      this.targetLanguage.set(lang);
    }
  }
  
  toggleSmartMode(event: Event): void {
    this.smartMode.set((event.target as HTMLInputElement).checked);
  }

  // --- Panel Dragging Methods ---
  dragStart(event: MouseEvent): void {
    if (event.button !== 0) return; // Only drag with left mouse button
    this.isDragging.set(true);
    this.dragOffset.set({
      x: event.clientX - this.panelPosition().x,
      y: event.clientY - this.panelPosition().y
    });
    event.preventDefault();
  }

  dragMove(event: MouseEvent): void {
    if (!this.isDragging()) return;
    this.panelPosition.set({
      x: event.clientX - this.dragOffset().x,
      y: event.clientY - this.dragOffset().y,
    });
  }

  dragEnd(): void {
    this.isDragging.set(false);
  }

  // --- Panel Control Methods ---
  closePanel(): void {
    this.isPanelVisible.set(false);
  }

  toggleMinimizePanel(): void {
    this.isPanelMinimized.update(minimized => !minimized);
  }

  showPanel(): void {
      this.isPanelVisible.set(true);
  }
}
