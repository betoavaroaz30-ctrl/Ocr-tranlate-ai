import { Injectable } from '@angular/core';
import { GoogleGenAI, Type } from '@google/genai';

export interface ComicTranslationBlock {
  original_text: string;
  translated_text: string;
  bounding_box: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    // IMPORTANT: The API key is injected via environment variables.
    // Do not expose this key in client-side code in a production environment.
    // This is for demonstration purposes in the Applet environment.
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  private fileToGenerativePart(file: File): Promise<{ inlineData: { mimeType: string, data: string } }> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const base64String = (reader.result as string).split(',')[1];
        resolve({
          inlineData: {
            mimeType: file.type,
            data: base64String,
          }
        });
      };
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(file);
    });
  }

  async translateComicPage(file: File, targetLang: string): Promise<ComicTranslationBlock[]> {
    const model = 'gemini-2.5-flash';
    const imagePart = await this.fileToGenerativePart(file);

    const prompt = `You are an expert comic book/manga translator. Analyze the following image.
1. Identify every single block of text (speech bubbles, narration boxes, sound effects, etc.).
2. For each block, provide its exact bounding box coordinates (x, y, width, height) as percentages of the total image dimensions.
3. Extract the original text from each block.
4. Translate the original text into ${targetLang}.
5. Return the result as a JSON array.`;

    const schema = {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          original_text: { type: Type.STRING },
          translated_text: { type: Type.STRING },
          bounding_box: {
            type: Type.OBJECT,
            properties: {
              x: { type: Type.NUMBER, description: 'Percentage from the left edge (0.0 to 100.0)' },
              y: { type: Type.NUMBER, description: 'Percentage from the top edge (0.0 to 100.0)' },
              width: { type: Type.NUMBER, description: 'Percentage width (0.0 to 100.0)' },
              height: { type: Type.NUMBER, description: 'Percentage height (0.0 to 100.0)' }
            },
            required: ['x', 'y', 'width', 'height']
          }
        },
        required: ['original_text', 'translated_text', 'bounding_box']
      }
    };

    try {
      const response = await this.ai.models.generateContent({
        model,
        contents: [{ parts: [imagePart, { text: prompt }] }],
        config: {
          responseMimeType: 'application/json',
          responseSchema: schema,
        }
      });

      const jsonText = response.text.trim();
      const result = JSON.parse(jsonText);
      return result as ComicTranslationBlock[];
    } catch (error) {
      console.error('Gemini API Error (translateComicPage):', error);
      throw new Error('Failed to translate comic page. The model may have returned an invalid format.');
    }
  }

  async extractTextFromImage(file: File): Promise<string> {
    const model = 'gemini-2.5-flash';
    const imagePart = await this.fileToGenerativePart(file);

    const textPart = {
      text: 'Extract all text from this image, including any handwritten text. Respond only with the extracted text. If no text is present, return an empty response.'
    };

    try {
      const response = await this.ai.models.generateContent({
        model,
        contents: [{ parts: [imagePart, textPart] }],
      });
      return response.text.trim();
    } catch (error) {
      console.error('Gemini API Error (extractTextFromImage):', error);
      throw new Error('Failed to extract text from image.');
    }
  }

  async extractTextFromVideo(file: File): Promise<string> {
    const model = 'gemini-2.5-flash';
    const videoPart = await this.fileToGenerativePart(file);

    const textPart = {
      text: 'Transcribe the audio from this video. Respond only with the transcribed text. If there is no audio or speech, return an empty response.'
    };

    try {
      const response = await this.ai.models.generateContent({
        model,
        contents: [{ parts: [videoPart, textPart] }],
      });
      return response.text.trim();
    } catch (error) {
      console.error('Gemini API Error (extractTextFromVideo):', error);
      throw new Error('Failed to transcribe video.');
    }
  }

  async translate(
    text: string,
    sourceLang: string,
    targetLang: string,
    smartMode: boolean
  ): Promise<{ translation: string; explanation: string | null; }> {
    if (!text.trim()) {
      return { translation: '', explanation: null };
    }

    const model = 'gemini-2.5-flash';

    if (smartMode) {
      const prompt = `You are an expert cultural translator. Your task is to translate text from ${sourceLang} to ${targetLang}.
- Provide the most natural and accurate translation.
- If the original text contains an idiom, slang, or a cultural reference that doesn't have a direct literal equivalent, provide the best-fitting idiomatic translation in the target language.
- After the translation, if and only if you performed a non-literal or culturally-adapted translation, add a brief, clear explanation for why the specific adaptation was made.

Text to translate:
"""
${text}
"""`;

      const schema = {
        type: Type.OBJECT,
        properties: {
          translation: { type: Type.STRING, description: `The translated text in ${targetLang}.` },
          explanation: { type: Type.STRING, description: 'An optional explanation for any non-literal translations.' }
        },
        required: ['translation']
      };

      try {
        const response = await this.ai.models.generateContent({
          model,
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
            responseSchema: schema,
          }
        });
        const jsonText = response.text.trim();
        const result = JSON.parse(jsonText);
        return {
          translation: result.translation || '',
          explanation: result.explanation || null,
        };
      } catch (error) {
        console.error('Gemini API Error (Smart Translate):', error);
        throw new Error('Failed to get smart translation from Gemini API.');
      }

    } else {
      const prompt = `You are an expert translator. Translate the following text from ${sourceLang} to ${targetLang}. Do not add any extra commentary, notes, or explanations. Just provide the direct translation.\n\nText to translate:\n"""\n${text}\n"""`;
      
      try {
        const response = await this.ai.models.generateContent({
          model,
          contents: prompt,
          config: { thinkingConfig: { thinkingBudget: 0 } }
        });
        return { translation: response.text, explanation: null };
      } catch (error) {
        console.error('Gemini API Error (Translate):', error);
        throw new Error('Failed to get translation from Gemini API. Please check your API key and network connection.');
      }
    }
  }

  async detectLanguage(text: string): Promise<string> {
    if (!text.trim()) {
      return '';
    }

    const model = 'gemini-2.5-flash';
    const prompt = `Detect the language of the following text. Respond with only the common English name of the language (e.g., "English", "Spanish", "Japanese"). Do not add any other words or punctuation.

Text:
"""
${text}
"""`;

    try {
      const response = await this.ai.models.generateContent({
        model,
        contents: prompt,
        config: { thinkingConfig: { thinkingBudget: 0 } } // Fast response needed
      });
      return response.text.trim();
    } catch (error) {
      console.error('Gemini API Error (detectLanguage):', error);
      throw new Error('Failed to detect language.');
    }
  }
}